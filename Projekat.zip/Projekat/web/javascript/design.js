/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//Poziva se u slucaju da korisnicko ime vec postoji u bazi prilikom registracije.
function usernameExists() {
    window.onload = function () {
        alert("Username already exists, please choose another username");
    };
}

//Poziva se u slucaju da proizvod vec postoji u bazi prilikom dodavanja novog proizvoda.
function productExists() {
    window.onload = function () {
        alert("Product already exists inside the database");
    };
}

//Poziva se u slucaju da pri kreaciji novog proizvoda fajl nije .jpg
function imageInvalid() {
    window.onload = function () {
        alert("Invalid image format");
    };
}

//Poziva se u slucaju da je neko od polja ostavljeno prazno prilikom 
//popunjavanja forme.
function fieldsEmpty() {
    window.onload = function () {
        alert("You must fill in all the fields required");
    };
}

//Poziva se u slucaju da je kombinacija korisnickog imena i sifre nepostojeca 
//prilikom logovanja.
function userInvalid() {
    window.onload = function () {
        alert("Invalid user!");
    };
}

//Poziva se u slucaju da je kupovina proizvoda uspesna.
function purchaseSuccess() {
    window.onload = function () {
        alert("Purchase successful!");
    };
}

//Poziva se prilikom uspesne registracije novog naloga.
function registerSuccess() {
    window.onload = function () {
        alert("Register successful!");
    };
}

//Poziva se prilikom uspesnog logina.
function loginSuccess() {
    window.onload = function () {
        alert("Login successful!");
    };
}

function newproductSuccess() {
    window.onload = function () {
        alert("New vehicle has been added successfully!");
    };
}

//Poziva se radi redirekcije na pocetnu stranu u slucaju neovlascenih pokusaja
//pristupa odredjenim stranicama.
function redirectToIndex() {
    window.onload = function () {
        location.href = "index.jsp";
    };
}

//Poziva se prilikom kupovine proizvoda radi potvrde kupovine, kako se ne bi
//desila slucajna transakcija.
function confirmBuy(Url) {
    if (confirm("Are you sure you want to buy this product?"))
    {
        document.location = Url;
    }
}