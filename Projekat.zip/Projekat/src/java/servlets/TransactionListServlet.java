/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import database.Upiti;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Transaction;

/**
 *
 * @author MG
 *
 * Ovaj servlet se pokrece klikom na dugme Transaction List bilo na stranici
 * Account (kada je ulogovan korisnik), bilo na stranici Administration (kada je
 * ulogovan administrator). Na imena korisnika i kupljenih proizvoda moze se
 * kliknuti, na sta se dobija nov ekran sa detaljima o korisniku/proizvodu.
 *
 * U slucaju da je trenutno ulogovan administrator, TransactionList stampa listu
 * svih transakcija koje administrator moze da potvrdi klikom na 'Approve'
 * dugme.
 *
 * U slucaju da je trenutno ulogovan korisnik, TransactionList stampa iskljucivo
 * listu transakcija koje je ulogovani korisnik obavio. Napomena: kod
 * korisnikove liste transakcija prikazuju se iskljucivo transakcije koje je
 * administrator potvrdio klikom na 'Approve', jer se tek tada racunaju kao
 * izvrsene.
 */
@WebServlet(name = "TransactionListServlet", urlPatterns = {"/TransactionListServlet"})
public class TransactionListServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
            out.println("<title>Transaction List - " + request.getSession().getAttribute("username").toString() + "</title>");
            out.println("<link rel=\"stylesheet\" type=\"text/css\" href=\"css/style.css\">");
            out.println("<script type=\"text/javascript\" src=\"javascript/design.js\"></script>");
            out.println("</head>");
            out.println("<body>");
            request.getRequestDispatcher("header.jsp").include(request, response);
            if ((request.getSession().getAttribute("username").toString()).equals("admin")) {
                ArrayList<Transaction> transakcije = Upiti.getTransactionListAdmin();
                out.println("<div class=\"transactionlist\">");
                out.println("<table>");
                out.println("<tr>");
                out.println("<th>Transaction ID</th>");
                out.println("<th>Date</th>");
                out.println("<th>Buyer</th>");
                out.println("<th>Product</th>");
                out.println("<th>Approved</th>");
                out.println("</tr>");
                for (int i = 0; i < transakcije.size(); i++) {
                    out.println("<tr>");
                    out.println("<td>" + transakcije.get(i).getTransaction_id() + "</td>");
                    out.println("<td>" + transakcije.get(i).getDate() + "</td>");
                    out.println("<td><a href=\"TransactionListUserServlet?username=" + transakcije.get(i).getUser() + "\">" + transakcije.get(i).getUser() + "</a></td>");
                    out.println("<td><a href=\"TransactionListItemServlet?productName=" + transakcije.get(i).getItem() + "\">" + transakcije.get(i).getItem() + "</a></td>");
                    if (transakcije.get(i).getApproved().equals("yes")) {
                        out.println("<td>Approved</td>");
                    } else {
                        out.println("<td><a href=\"ValidateServlet?transactionID=" + transakcije.get(i).getTransaction_id() + "\" class=\"validatebutton\">Approve</a></td>");
                    }
                    out.println("</tr>");
                }
                out.println("</table>");
                out.println("</div>");
            } else {
                int user_id = Integer.parseInt(request.getSession().getAttribute("userID").toString());
                ArrayList<Transaction> transakcije = Upiti.getTransactionListUser(user_id);
                out.println("<div class=\"transactionlist\">");
                out.println("<table>");
                out.println("<tr>");
                out.println("<th>Transaction ID</th>");
                out.println("<th>Date</th>");
                out.println("<th>Product</th>");
                out.println("</tr>");
                for (int i = 0; i < transakcije.size(); i++) {
                    if (transakcije.get(i).getApproved().equals("yes")) {
                        out.println("<tr>");
                        out.println("<td>" + transakcije.get(i).getTransaction_id() + "</td>");
                        out.println("<td>" + transakcije.get(i).getDate() + "</td>");
                        out.println("<td><a href=\"TransactionListItemServlet?productName=" + transakcije.get(i).getItem() + "\">" + transakcije.get(i).getItem() + "</a></td>");
                        out.println("</tr>");
                    }
                }
                out.println("</table>");
                out.println("</div>");
            }
            request.getRequestDispatcher("footer.jsp").include(request, response);
            out.println("</body>");
            out.println("</html>");
        }
    }

// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
