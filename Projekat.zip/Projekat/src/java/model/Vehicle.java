package model;

/**
 *
 * @author MG
 */
public class Vehicle {

    private int vehicle_id;
    private double price;
    private String name, description, category, manufacturer, image;

    public Vehicle(int vehicle_id, double price, String name, String description, String category, String manufacturer, String image) {
        this.vehicle_id = vehicle_id;
        this.price = price;
        this.name = name;
        this.description = description;
        this.category = category;
        this.manufacturer = manufacturer;
        this.image = image;
    }

    public Vehicle(double price, String name, String description, String category, String manufacturer, String image) {
        this.price = price;
        this.name = name;
        this.description = description;
        this.category = category;
        this.manufacturer = manufacturer;
        this.image = image;
    }

    public Vehicle() {
    }

    public int getVehicle_id() {
        return vehicle_id;
    }

    public void setVehicle_id(int vehicle_id) {
        this.vehicle_id = vehicle_id;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    @Override
    public String toString() {
        return "Vehicle{" + "vehicle_id=" + vehicle_id + ", price=" + price + ", name=" + name + ", description=" + description + ", category=" + category + ", manufacturer=" + manufacturer + ", image=" + image + '}';
    }

    

    
    
    
}
