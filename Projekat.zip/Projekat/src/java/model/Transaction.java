package model;

/**
 * @author MG
 */
public class Transaction {

    int transaction_id;
    String date, user, item, approved;

    public Transaction() {
    }

    public Transaction(int transaction_id, String date, String user, String item, String approved) {
        this.transaction_id = transaction_id;
        this.date = date;
        this.user = user;
        this.item = item;
        this.approved = approved;
    }

    public Transaction(String date, String user, String item, String approved) {
        this.date = date;
        this.user = user;
        this.item = item;
        this.approved = approved;
    }

    public int getTransaction_id() {
        return transaction_id;
    }

    public void setTransaction_id(int transaction_id) {
        this.transaction_id = transaction_id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getApproved() {
        return approved;
    }

    public void setApproved(String approved) {
        this.approved = approved;
    }

    @Override
    public String toString() {
        return "Transaction{" + "transaction_id=" + transaction_id + ", date=" + date + ", user=" + user + ", item=" + item + ", approved=" + approved + '}';
    }
}
