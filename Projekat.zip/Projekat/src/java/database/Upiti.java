package database;

/**
 *
 * @author MG
 *
 * Ova klasa sadrzi upite koji se salju u bazu radi izmene ili dohvatanja
 * podataka.
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Vehicle;
import model.Transaction;
import model.User;

public class Upiti {

    //Kreira ArrayList za stampanje stranice sa proizvodima pomocu ProductServleta,
    public static ArrayList<Vehicle> getAllProductsFromCategory(int cat_id) {
        String upit = "select * from item where category =" + cat_id + ";";
        ArrayList<Vehicle> vozila
                = new ArrayList<>();

        DbUtil instanca = DbUtil.getInstance();
        Connection baza = instanca.getConn();
        try {
            Statement st = baza.createStatement();
            ResultSet rs = st.executeQuery(upit);

            while (rs.next()) {
                Vehicle v
                        = new Vehicle(rs.getInt(1), rs.getDouble(5), rs.getString(2), rs.getString(6), getCategory(rs.getInt(3)), getManufacturer(rs.getInt(4)), rs.getString(7));

                vozila.add(v);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Upiti.class.getName()).log(Level.SEVERE, null, ex);
        }
        return vozila;
    }

    //Konvertuje id kategorije u ime kategorije za getAllProducsFromCategory
    public static String getCategory(int cat_id) {
        String upit = "select name from category where category_id=" + cat_id + ";";
        String name = "";

        DbUtil instanca = DbUtil.getInstance();
        Connection baza = instanca.getConn();
        try {
            Statement st = baza.createStatement();
            ResultSet rs = st.executeQuery(upit);
            rs.next();
            name = rs.getString(1);

        } catch (SQLException ex) {
            Logger.getLogger(Upiti.class.getName()).log(Level.SEVERE, null, ex);
        }
        return name;
    }

    //Konvertuje id proizvodjaca u ime proizvodjaca za getAllProducsFromCategory
    public static String getManufacturer(int man_id) {
        String upit = "select name from manufacturer where manufacturer_id=" + man_id + ";";
        String name = "";

        DbUtil instanca = DbUtil.getInstance();
        Connection baza = instanca.getConn();
        try {
            Statement st = baza.createStatement();
            ResultSet rs = st.executeQuery(upit);
            rs.next();
            name = rs.getString(1);

        } catch (SQLException ex) {
            Logger.getLogger(Upiti.class.getName()).log(Level.SEVERE, null, ex);
        }
        return name;
    }

    //Salje update u bazu sa podacima novog korisnika iz RegisterServleta
    public static void RegisterUser(User u) {
        String upit = "insert into user (first_name, last_name, phone, email, address, username, password) values "
                + "('" + u.getFirst_name() + "', '" + u.getLast_name() + "', '" + u.getPhone() + "', '" + u.getEmail() + "', '" + u.getAddress() + "', '" + u.getUsername() + "', md5('" + u.getPassword() + "'));";
        try {
            DbUtil instanca = DbUtil.getInstance();
            Connection baza = instanca.getConn();
            Statement st = baza.createStatement();
            st.executeUpdate(upit);
        } catch (SQLException ex) {
            Logger.getLogger(Upiti.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //Konvertuje ime proizvodjaca u id proizvodjaca za CreateNewProduct
    public static int getManufacturerId(String name) {
        String upit = "select manufacturer_id from manufacturer where name='" + name + "';";
        int id = 0;

        DbUtil instanca = DbUtil.getInstance();
        Connection baza = instanca.getConn();
        try {
            Statement st = baza.createStatement();
            ResultSet rs = st.executeQuery(upit);
            rs.next();
            id = rs.getInt(1);

        } catch (SQLException ex) {
            Logger.getLogger(Upiti.class.getName()).log(Level.SEVERE, null, ex);
        }
        return id;
    }

    //Konvertuje ime kategorije u id kategorije za CreateNewProduct
    public static int getCategoryId(String name) {
        String upit = "select category_id from category where name='" + name +"s" + "';";
        int id = 0;
        try {
        DbUtil instanca = DbUtil.getInstance();
        Connection baza = instanca.getConn();
        
            Statement st = baza.createStatement();
            ResultSet rs = st.executeQuery(upit);
            rs.next();
            id = rs.getInt(1);
        } catch (SQLException ex) {
            Logger.getLogger(Upiti.class.getName()).log(Level.SEVERE, null, ex);
        }
        return id;
    }

    //Salje insert u bazu sa podacima novog proizvoda.
    public static void CreateNewProduct(Vehicle v) {
        String upit = "insert into item (name, category, manufacturer, price, description, image) values "
                + "('" + v.getName() + "', '" + getCategoryId(v.getCategory()) + "', '" + getManufacturerId(v.getManufacturer())
                + "', '" + v.getPrice() + "', '" + v.getDescription() + "', '" + v.getImage() + "');";
        try {
            DbUtil instanca = DbUtil.getInstance();
            Connection baza = instanca.getConn();
            Statement st = baza.createStatement();
            st.executeUpdate(upit);
        } catch (SQLException ex) {
            Logger.getLogger(Upiti.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //Proverava da li username vec postoji u bazi prilikom registracije korisnika u RegisterServletu
    public static boolean doesUserExist(String username) {
        boolean exists = false;
        String upit = "select * from user where username ='" + username + "';";
        try {
            DbUtil instanca = DbUtil.getInstance();
            Connection baza = instanca.getConn();
            PreparedStatement ps = baza.prepareStatement(upit);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                exists = true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Upiti.class.getName()).log(Level.SEVERE, null, ex);
        }

        return exists;
    }

    //Proverava da li proizvod vec postoji u bazi prilikom dodavanja novih proizvoda.
    public static boolean doesProductExist(String name) {
        boolean exists = false;
        String upit = "select * from item where name ='" + name + "';";
        try {
            DbUtil instanca = DbUtil.getInstance();
            Connection baza = instanca.getConn();
            PreparedStatement ps = baza.prepareStatement(upit);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                exists = true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Upiti.class.getName()).log(Level.SEVERE, null, ex);
        }

        return exists;
    }

    //Proverava da li korisnik postoji pri logovanju u LoginServletu
    public static boolean isUserValid(String username, String password) {
        boolean isValid = false;
        String upit = "select * from user where username = ? and password = md5(?)";
        try {
            DbUtil instanca = DbUtil.getInstance();
            Connection baza = instanca.getConn();
            PreparedStatement ps = baza.prepareStatement(upit);
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                isValid = true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Upiti.class.getName()).log(Level.SEVERE, null, ex);
        }

        return isValid;
    }

    //Vraca id korisnika za atribut sesije u LoginServletu
    public static int isUserValidReturnId(String username, String password) {
        String upit = "select user_id from user where username = ? and password = md5(?)";
        try {
            DbUtil instanca = DbUtil.getInstance();
            Connection baza = instanca.getConn();
            PreparedStatement ps = baza.prepareStatement(upit);
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Upiti.class.getName()).log(Level.SEVERE, null, ex);
        }

        return -1;
    }

    //Dohvata podatke o korisniku za prikaz na stranici account.jsp
    public static User getUser(int user_id) {
        String upit = "select * from user where user_id=" + user_id + ";";
        User u = new User();
        try {
            DbUtil instanca = DbUtil.getInstance();
            Connection baza = instanca.getConn();
            PreparedStatement ps = baza.prepareStatement(upit);
            ResultSet rs = ps.executeQuery();
            rs.next();

            u.setUser_id(rs.getInt(1));
            u.setFirst_name(rs.getString(2));
            u.setLast_name(rs.getString(3));
            u.setPhone(rs.getString(4));
            u.setEmail(rs.getString(5));
            u.setAddress(rs.getString(6));
            u.setUsername(rs.getString(7));
            u.setPassword(rs.getString(8));
        } catch (SQLException ex) {
            Logger.getLogger(Upiti.class.getName()).log(Level.SEVERE, null, ex);
        }
        return u;
    }

    //Upit koji upisuje kupljeni proizvod u tabelu transaction iz PurchaseServleta
    public static void PurchaseProduct(String date, int item_id, int user_id) {
        String upit = "insert into transaction (date, user, item, approved) values ('" + date + "', " + user_id + ", " + item_id + ", 'no');";
        try {
            DbUtil instanca = DbUtil.getInstance();
            Connection baza = instanca.getConn();
            Statement st = baza.createStatement();
            st.executeUpdate(upit);
        } catch (SQLException ex) {
            Logger.getLogger(Upiti.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //Dohvata username iz user tabele u formi Stringa za getTransactionListUser metodu ispod
    public static String getUsernameForTransactionList(int user_id) {
        String upit = "select username from user where user_id=" + user_id + ";";
        String username = "";

        DbUtil instanca = DbUtil.getInstance();
        Connection baza = instanca.getConn();
        try {
            Statement st = baza.createStatement();
            ResultSet rs = st.executeQuery(upit);
            rs.next();
            username = rs.getString(1);

        } catch (SQLException ex) {
            Logger.getLogger(Upiti.class.getName()).log(Level.SEVERE, null, ex);
        }
        return username;
    }

    //Dohvata ime proizvoda iz item tabele u formi Stringa za getTransactionListUser metodu ispod
    public static String getItemNameForTransactionList(int item_id) {
        String upit = "select name from item where item_id=" + item_id + ";";
        String item = "";

        DbUtil instanca = DbUtil.getInstance();
        Connection baza = instanca.getConn();
        try {
            Statement st = baza.createStatement();
            ResultSet rs = st.executeQuery(upit);
            rs.next();
            item = rs.getString(1);

        } catch (SQLException ex) {
            Logger.getLogger(Upiti.class.getName()).log(Level.SEVERE, null, ex);
        }
        return item;
    }

    //Pravi ArrayListu transakcija iz tabele transaction za TransactionListServlet za *korisnika*
    public static ArrayList<Transaction> getTransactionListUser(int user_id) {
        String upit = "select * from transaction where user=" + user_id + ";";
        ArrayList<Transaction> transakcije
                = new ArrayList<>();

        DbUtil instanca = DbUtil.getInstance();
        Connection baza = instanca.getConn();
        try {
            Statement st = baza.createStatement();
            ResultSet rs = st.executeQuery(upit);

            while (rs.next()) {
                Transaction t
                        = new Transaction(rs.getInt(1), rs.getString(2), getUsernameForTransactionList(rs.getInt(3)), getItemNameForTransactionList(rs.getInt(4)), rs.getString(5));

                transakcije.add(t);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Upiti.class.getName()).log(Level.SEVERE, null, ex);
        }
        return transakcije;
    }

    //Pravi ArrayListu transakcija iz tabele transaction za TransactionListServlet za *administratora*
    public static ArrayList<Transaction> getTransactionListAdmin() {
        String upit = "select * from transaction;";
        ArrayList<Transaction> transakcije
                = new ArrayList<>();

        DbUtil instanca = DbUtil.getInstance();
        Connection baza = instanca.getConn();
        try {
            Statement st = baza.createStatement();
            ResultSet rs = st.executeQuery(upit);

            while (rs.next()) {
                Transaction t
                        = new Transaction(rs.getInt(1), rs.getString(2), getUsernameForTransactionList(rs.getInt(3)), getItemNameForTransactionList(rs.getInt(4)), rs.getString(5));

                transakcije.add(t);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Upiti.class.getName()).log(Level.SEVERE, null, ex);
        }
        return transakcije;
    }

    //Dohvata podatke iz tabele item i pravi Proizvod za TransactionListItemServlet
    public static Vehicle getProductForTransactionList(String name) {
        String upit = "select * from item where name ='" + name + "';";
        Vehicle v = new Vehicle();
        try {
            DbUtil instanca = DbUtil.getInstance();
            Connection baza = instanca.getConn();
            Statement st = baza.createStatement();
            ResultSet rs = st.executeQuery(upit);
            rs.next();

            v.setVehicle_id(rs.getInt(1));
            v.setPrice(rs.getDouble(5));
            v.setName(rs.getString(2));
            v.setDescription(rs.getString(6));
            v.setCategory(getCategory(rs.getInt(3)));
            v.setManufacturer(getManufacturer(rs.getInt(4)));
            v.setImage(rs.getString(7));
        } catch (SQLException ex) {
            Logger.getLogger(Upiti.class.getName()).log(Level.SEVERE, null, ex);
        }
        return v;
    }

    //Dohvata podatke i pravi Usera za TransactionListUserServlet
    public static User getUserForTransactionList(String username) {
        String upit = "select * from user where username='" + username + "';";
        User u = new User();
        try {
            DbUtil instanca = DbUtil.getInstance();
            Connection baza = instanca.getConn();
            PreparedStatement ps = baza.prepareStatement(upit);
            ResultSet rs = ps.executeQuery();
            rs.next();

            u.setUser_id(rs.getInt(1));
            u.setFirst_name(rs.getString(2));
            u.setLast_name(rs.getString(3));
            u.setPhone(rs.getString(4));
            u.setEmail(rs.getString(5));
            u.setAddress(rs.getString(6));
            u.setUsername(rs.getString(7));
            u.setPassword(rs.getString(8));
        } catch (SQLException ex) {
            Logger.getLogger(Upiti.class.getName()).log(Level.SEVERE, null, ex);
        }
        return u;
    }

    //Validira transakciju tako sto u tabeli transaction updateuje kolonu approved na 'yes'
    public static void ValidatePurchase(int transaction_id) {
        String upit = "update transaction set approved='yes' where transaction_id=" + transaction_id + ";";
        try {
            DbUtil instanca = DbUtil.getInstance();
            Connection baza = instanca.getConn();
            Statement st = baza.createStatement();
            st.executeUpdate(upit);
        } catch (SQLException ex) {
            Logger.getLogger(Upiti.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //Dohvata korisnike i pravi listu za prikaz na UserListServlet za administratora
    public static ArrayList<User> getUsersForUserList() {
        String upit = "select * from user;";
        ArrayList<User> korisnici
                = new ArrayList<>();

        DbUtil instanca = DbUtil.getInstance();
        Connection baza = instanca.getConn();
        try {
            Statement st = baza.createStatement();
            ResultSet rs = st.executeQuery(upit);

            while (rs.next()) {
                User u
                        = new User(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8));

                korisnici.add(u);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Upiti.class.getName()).log(Level.SEVERE, null, ex);
        }
        return korisnici;
    }
}
